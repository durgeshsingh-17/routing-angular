import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sagar',
  templateUrl: './sagar.component.html',
  styleUrls: ['./sagar.component.scss']
})
export class SagarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
