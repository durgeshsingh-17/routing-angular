import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SagarComponent } from './sagar.component';
import { SagarRoutingModule } from './sagar-routing.module';



@NgModule({
  declarations: [
    SagarComponent
  ],
  imports: [
    CommonModule,
    SagarRoutingModule
  ]
})
export class SagarModule { }
