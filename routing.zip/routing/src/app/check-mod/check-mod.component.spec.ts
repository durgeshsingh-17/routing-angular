import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckModComponent } from './check-mod.component';

describe('CheckModComponent', () => {
  let component: CheckModComponent;
  let fixture: ComponentFixture<CheckModComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckModComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckModComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
