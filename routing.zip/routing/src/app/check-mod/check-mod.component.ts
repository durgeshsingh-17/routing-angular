import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-mod',
  templateUrl: './check-mod.component.html',
  styleUrls: ['./check-mod.component.scss']
})
export class CheckModComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
