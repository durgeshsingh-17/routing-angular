import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CheckModRoutingModule } from './check-mod-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CheckModRoutingModule
    
  ]
})
export class CheckModModule { }
