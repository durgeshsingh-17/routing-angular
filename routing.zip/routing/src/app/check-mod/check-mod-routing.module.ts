import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckModComponent } from './check-mod.component';


const routes: Routes = [
  {
    path: '', component: CheckModComponent,
    children: [
      {path: 'faisal', loadChildren: () => import('./faisal/faisal.module').then((m) => m.FaisalModule)},
      {path: 'sagar', loadChildren: ()=> import('./sagar/sagar.module').then((m) => m.SagarModule)},
    ],
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CheckModRoutingModule { }
