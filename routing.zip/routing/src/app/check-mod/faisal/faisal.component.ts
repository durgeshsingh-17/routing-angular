import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faisal',
  templateUrl: './faisal.component.html',
  styleUrls: ['./faisal.component.scss']
})
export class FaisalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
