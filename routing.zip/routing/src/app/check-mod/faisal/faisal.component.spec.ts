import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaisalComponent } from './faisal.component';

describe('FaisalComponent', () => {
  let component: FaisalComponent;
  let fixture: ComponentFixture<FaisalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FaisalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FaisalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
