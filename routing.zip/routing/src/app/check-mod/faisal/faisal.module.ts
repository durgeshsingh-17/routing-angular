import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FaisalComponent } from './faisal.component';
import { FaisalRoutingModule } from './faisal.routing.module';



@NgModule({
  declarations: [
    FaisalComponent
  ],
  imports: [
    CommonModule,
    FaisalRoutingModule
  ]
})
export class FaisalModule { }
